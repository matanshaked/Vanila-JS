import Organic  from '../js/widgets/Organic.js'; 
import { RecommendationsTypes } from '../js/consts.js';
import { createBaseMock, organicMockRespose } from './testMockData.js';

const recommendationType = RecommendationsTypes.ORGANIC; 



test(`Start testing and validating of dom structure of the ${recommendationType} recommendation widget (case of valid response):`, () => {


	//mock data
	const organic = new Organic();
	const flexContainer = createBaseMock(organic);

	//Data preperation and excuting class (valid case):
	document.body.innerHTML = '<div id="main" />';

	const res = organicMockRespose;

	const main = document.getElementById('main');
	if (res && res.list  && res.list.length > 0) {
		
		const organicNode = organic.createOrganic(RecommendationsTypes.ORGANIC, res.list);
		organicNode && main.appendChild(organicNode);
		main.appendChild(document.createElement('br'));

	}

	//Start testing:


	let firstRecommendation;
	//check for Truthy of existance of first item node
	firstRecommendation = flexContainer.children[0];
	expect(firstRecommendation).toBeTruthy();


	//check for number of recommendation items as per input inserted
	expect(flexContainer.children.length).toBe(4);



	//Start test the content validity of first item

	//check for Truthy of existance of A node in  item node
	let thumbnailA;
	for (const el of firstRecommendation.children) {
		if (el.nodeName  === 'A') {
			thumbnailA = el;
			break;
		}
	}
	expect(thumbnailA).toBeTruthy();


	//check for content existance of "href" attribute in A node
	expect(thumbnailA.getAttribute('href')).toBeTruthy();


	//check for Truthy of existance of IMG node in A node
	let thumbnailImg;
	for (const el of thumbnailA.children) {
		if (el.nodeName  === 'IMG') {
			thumbnailImg = el;
			break;
		}
	}
	expect(thumbnailImg).toBeTruthy();


	//check for content existance of "src" attribute in IMG node
	expect(thumbnailImg.getAttribute('src')).toBeTruthy();


	//check for Truthy of existance of recommendation-content class
	let recommendatioContent;
	for (const el of firstRecommendation.children) {
		if (el.className === 'recommendation-content') {
			recommendatioContent = el;
			break;
		}
	}
	expect(recommendatioContent).toBeTruthy();


	//check for Truthy of existance of content in caption
	let recommendatioCaption;
	for (const el of recommendatioContent.children) {
		if (el.className === `${recommendationType}-caption`) {
			recommendatioCaption = el;
			break;
		}
	}
	expect(recommendatioCaption.innerHTML).toBeTruthy();

});

test(`Start testing and validating of dom structure of the ${recommendationType} recommendation widget (case of empty response):`, () => {

	//Data preperation and excuting class (empty response case):

	document.body.innerHTML = '<div id="main" />';

	const res = JSON.parse('{}');

	const main = document.getElementById('main');
	if (res && res.list  && res.list.length > 0) {
		const organic = new Organic();
		const organicNode = organic.createOrganic(recommendationType, res.list);
		organicNode && main.appendChild(organicNode);
		main.appendChild(document.createElement('br'));
	}

	//Test to make sure no dom nodes appened and created if no data came for recommendation
	expect(main.children.length).toBe(0);
});




