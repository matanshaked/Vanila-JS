import BaseRecommendation  from '../js/widgets/base/BaseRecommendation.js';


test('Start testing and validating of dom structure of the base recommendation:', () => {

	const { containerDiv, mainTitleDiv, mainGridDiv } = new BaseRecommendation().createBaseStructure();

	expect(mainGridDiv.className).toBe('main-grid');

	
	
	//check for Truthy of existance of main container class
	let mainContainer;
	for (const el of mainGridDiv.children) {
		if (el.className === 'main-container') {
			mainContainer = el;
			break;
		}
	}
	expect(mainContainer).toBeTruthy();
	

	//check for Truthy of existance of flex-container class
	let flexContainer;
	for (const el of mainContainer.children) {
		if (el.className === 'flex-container') {
			flexContainer = el;
			break;
		}
	}
	expect(flexContainer).toBeTruthy();
});