export const isValidImageURL = async (url) => {
	try {
		const res = await fetch(url);
		return !!res;

	} catch (err) {
		return false;
	}

};
