export const RecommendationsTypes = {
	SPONSORED: 'sponsored',
	ORGANIC: 'organic',
};
