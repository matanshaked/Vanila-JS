import { sponsoredTitle } from '../config.js';
import BaseRecommendation from './base/BaseRecommendation.js';
import { isValidImageURL } from '../utils.js';




export default  class Sponsored extends BaseRecommendation{
	async createSponsored (type, recommendationList)  {

		// DOM elements base structure
		const { containerDiv, mainTitleDiv, mainGridDiv } = this.createBaseStructure();

		for (const recommendation of recommendationList) {

			const thumbnailURL = recommendation.thumbnail && recommendation.thumbnail.find(el => 'url' in el);
			const validImageURL = await isValidImageURL(thumbnailURL.url);
			
			if (validImageURL) {

				// DOM elements structure
				const recommendationDiv = document.createElement('div');
				const thumbnailA = document.createElement('a');
				const thumbnailImg = document.createElement('img');
				const captionDiv = document.createElement('div');
				const sourceDiv = document.createElement('div');
				const recommendationGridDiv = document.createElement('div');
				const recommendationTextContentDiv = document.createElement('div');

				thumbnailA.appendChild(thumbnailImg);
				recommendationTextContentDiv.appendChild(captionDiv);
				recommendationTextContentDiv.appendChild(document.createElement('br'));
				recommendationTextContentDiv.appendChild(sourceDiv);
				recommendationGridDiv.appendChild(thumbnailA);
				recommendationGridDiv.appendChild(recommendationTextContentDiv);
				recommendationDiv.appendChild(recommendationGridDiv);
				containerDiv.appendChild(recommendationDiv);

				//set data and attributes
				recommendationDiv.setAttribute('class', `${type}-flex-item`);
				thumbnailA.setAttribute('target', '_blank');
				thumbnailA.setAttribute('href', recommendation.url);

				thumbnailImg.setAttribute('src', thumbnailURL.url);
				thumbnailImg.setAttribute('class', `${type}-recommendation-img`);

				captionDiv.textContent = recommendation.name;
				captionDiv.setAttribute('class', `${type}-caption`);

				sourceDiv.textContent = recommendation.branding;
				sourceDiv.setAttribute('class', 'source');

				recommendationGridDiv.setAttribute('class', 'recommendation-grid');
				recommendationTextContentDiv.setAttribute('class', 'recommendation-content');
			}
		}

		mainTitleDiv.textContent = sponsoredTitle;
		return containerDiv.children.length > 0 ? mainGridDiv : null;
	}

}