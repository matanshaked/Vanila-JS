export default class BaseRecommendation {

	// Method
	createBaseStructure () {
		const mainGridDiv = document.createElement('div');
		const mainContainerDiv = document.createElement('div');
		const mainTitleDiv = document.createElement('div');
		const containerDiv = document.createElement('div');
    
		mainContainerDiv.appendChild(mainTitleDiv);
		mainContainerDiv.appendChild(containerDiv);
		mainGridDiv.appendChild(document.createElement('br'));
		mainGridDiv.appendChild(mainContainerDiv);
    
    
		mainTitleDiv.setAttribute('class', 'main-title');
		containerDiv.setAttribute('class', 'flex-container');
		mainContainerDiv.setAttribute('class', 'main-container');
		mainGridDiv.setAttribute('class', 'main-grid');
    
    
		return { containerDiv, mainTitleDiv, mainGridDiv };
	}
}