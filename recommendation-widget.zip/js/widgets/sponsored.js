import { createRecommendationStructure, createBaseStructure } from '../utils.js';

export const createSponsored = (type, recomandationList) => {

  // DOM elements base structure
  const { mainContainerDiv, title, mainGridDiv, mainDiv } = createBaseStructure();
  console.log("recomandationList", recomandationList);

  for (const recomandation of recomandationList) {

    // DOM elements structure
    const { recomandationDiv, thumbnailA, thumbnailImg, captionDiv, sourceDiv,
      recomandationGridDiv, recomandationTextContentDiv } = createRecommendationStructure(mainContainerDiv, type);


    //set data and attributes
    recomandationDiv.setAttribute('class', 'flex-item');
    thumbnailA.setAttribute('target', '_blank');
    thumbnailA.setAttribute('href', recomandation.url);

    const thumbnailURL = recomandation.thumbnail && recomandation.thumbnail.find(el => 'url' in el);
    thumbnailImg.setAttribute('src', thumbnailURL.url);
    thumbnailImg.setAttribute('class', 'recomandation-img');

    captionDiv.textContent = recomandation.name;
    captionDiv.setAttribute('class', 'caption');

    sourceDiv.textContent = recomandation.branding;
    recomandationGridDiv.setAttribute('class', 'recomandation-grid');
    recomandationTextContentDiv.setAttribute('class', 'recomandation-content');
  }

  title.textContent = type;
  mainGridDiv.setAttribute('class', 'grid');
  mainContainerDiv.setAttribute('class', 'flex-container');

  return mainDiv;
}