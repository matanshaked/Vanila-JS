import { createRecommendationStructure, createBaseStructure } from '../utils.js';

export const createOrganic = (type, recomandationList) => {

  // DOM elements base structure
  const { mainContainerDiv, title, mainGridDiv, mainDiv } = createBaseStructure();

  for (const recomandation of recomandationList) {

    // DOM elements structure
    const { recomandationDiv, thumbnailA, thumbnailImg, captionDiv,
      recomandationGridDiv, recomandationTextContentDiv } = createRecommendationStructure(mainContainerDiv, type);


    //set data and attributes
    recomandationDiv.setAttribute('class', 'flex-item');
    thumbnailA.setAttribute('target', '_self');
    thumbnailA.setAttribute('href', recomandation.url);

    const thumbnailURL = recomandation.thumbnail && recomandation.thumbnail.find(el => 'url' in el);
    thumbnailImg.setAttribute('src', thumbnailURL.url);
    thumbnailImg.setAttribute('class', 'recomandation-img');

    captionDiv.textContent = recomandation.name;
    captionDiv.setAttribute('class', 'caption');

    recomandationGridDiv.setAttribute('class', 'recomandation-grid');
    recomandationTextContentDiv.setAttribute('class', 'recomandation-content');
  }

  title.textContent = type;
  mainGridDiv.setAttribute('class', 'grid');
  mainContainerDiv.setAttribute('class', 'flex-container');

  return mainDiv;
}