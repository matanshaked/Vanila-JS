import { RecommendationsTypes } from './consts.js';

export const createRecommendationStructure = (mainContainerDiv, type) => {
    const recomandationDiv = document.createElement('div');
    const thumbnailA = document.createElement('a');
    const thumbnailImg = document.createElement('img');
    const captionDiv = document.createElement('div');
    let sourceDiv;
    if (type === RecommendationsTypes.SPONSORED) {
        sourceDiv = document.createElement('div');
    }
    const recomandationGridDiv = document.createElement('div');
    const recomandationTextContentDiv = document.createElement('div');

    thumbnailA.appendChild(thumbnailImg);
    recomandationTextContentDiv.appendChild(captionDiv);
    recomandationTextContentDiv.appendChild(document.createElement('br'));
    if (type === RecommendationsTypes.SPONSORED) {
        recomandationTextContentDiv.appendChild(sourceDiv);
    }
    recomandationGridDiv.appendChild(thumbnailA);
    recomandationGridDiv.appendChild(recomandationTextContentDiv);
    recomandationDiv.appendChild(recomandationGridDiv);
    mainContainerDiv.appendChild(recomandationDiv);
    return { recomandationDiv, thumbnailA, thumbnailImg, captionDiv, sourceDiv, recomandationGridDiv, recomandationTextContentDiv };
}

export const createBaseStructure = () => {
    const mainDiv = document.createElement('div');
    const title = document.createElement('h3');
    const mainGridDiv = document.createElement('div');
    const mainContainerDiv = document.createElement('div');

    mainGridDiv.appendChild(document.createElement('br'));
    mainGridDiv.appendChild(mainContainerDiv);
    mainDiv.appendChild(title);
    mainDiv.appendChild(mainGridDiv);
    return { mainContainerDiv, title, mainGridDiv, mainDiv };
}