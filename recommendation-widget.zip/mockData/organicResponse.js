export const organicResponse = JSON.parse(
  '{"list":[{"name":"organic 1","url":"https://google.com","thumbnail":[{"url":"https://www.w3schools.com/howto/img_forest.jpg"}]},{"name":"organic 2","url":"https://google.com","thumbnail":[{"url":"https://www.w3schools.com/howto/img_forest.jpg"}]},{"name":"organic 3","url":"https://google.com","thumbnail":[{"url":"https://www.w3schools.com/howto/img_forest.jpg"}]},{"name":"organic 4","url":"https://google.com","thumbnail":[{"url":"https://www.w3schools.com/howto/img_forest.jpg"}]}]}'
);
