import { RecommendationsTypesOptiones, sponsoredURL } from './js/config.js';
import { RecommendationsTypes } from './js/consts.js';
import { organicResponse } from './mockData/organicResponse.js';
import { createSponsored } from './js/widgets/sponsored.js';
import { createOrganic } from './js/widgets/organic.js';


for (const option of RecommendationsTypesOptiones) {
  if (option === RecommendationsTypes.SPONSORED) {
    getSponsoredRecommendations().then(res => {
      if (res && res.length > 0) {
        const sponsoredNode = createSponsored(RecommendationsTypes.SPONSORED, res);
        sponsoredNode && main.appendChild(sponsoredNode);
      }
    });
  }

  if (option === RecommendationsTypes.ORGANIC) {
    const organicResponse = getOrganicRecommendations();
    const organicNode = organicResponse && createOrganic(RecommendationsTypes.ORGANIC, organicResponse);
    organicNode && main.appendChild(organicNode);
  }
}

async function getSponsoredRecommendations() {
  const api = sponsoredURL;

  const res = await fetch(api).then(response => { return response.json(); });
  return res && res.list;
}

function getOrganicRecommendations() {
  return organicResponse && organicResponse.list;
}


